tweetdf<-read.csv("twitter_data_techchallenge3.0.csv",stringsAsFactors = F)
emotiondf<-read.csv("tweetemotion.csv",stringsAsFactors = F)
sentimentdata<-read.csv("sentiment.csv",stringsAsFactors = F)
twitterstats<-read.csv("twitterstats.csv",stringsAsFactors = F)
tweetcnt<-read.csv("tweetcnt.csv",stringsAsFactors = F)
contactcnt<-read.csv("contactcnt.csv",stringsAsFactors = F)
sentimentavg<-read.csv("sentimentuser.csv",stringsAsFactors = F)
str(twitterstats)

str(tweetcnt)
tweetcnt$Userid<-tweetcnt$userid
tweetcnt$userid<-NULL

contactcnt$Userid<-contactcnt$userid
contactcnt$userid<-NULL
finalds<-merge(twitterstats,tweetcnt,by="Userid")
str(finalds)
finalds<-merge(finalds,contactcnt,by="Userid")
str(finalds)
sentimentavg$Userid<-sentimentavg$userid
sentimentavg$userid<-NULL
str(sentimentavg)
finalds<-merge(finalds,sentimentavg,by="Userid")
str(finalds)
vars<-colnames(finalds)[-1]
scaletweet<-scale(finalds[,vars])
str(scaletweet)
d<-dist(scaletweet,method="euclidean")
fit<-hclust(d,method="ward")
plot(fit)
rect.hclust(fit, k=2)
groups <- cutree(fit, k=2)

library(ggplot2)
princ <- prcomp(scaletweet)
nComp <- 2
project <- predict(princ, newdata=scaletweet)[,1:nComp]
project.plus <- cbind(as.data.frame(project),
                      cluster=as.factor(userid))
ggplot(project.plus, aes(x=PC1, y=PC2)) +
  geom_point(aes(shape=cluster)) +
  geom_text(aes(label=country),
            hjust=0, vjust=1)

library("fpc")
clustering.ch <- kmeansruns(scaletweet, krange=1:10, criterion="ch")
clustering.ch$bestk
clustering.asw <- kmeansruns(scaletweet, krange=1:10, criterion="asw")
clustering.asw$bestk