library(twitteR)

consumer_key <- 'XXX'

consumer_secret <- 'XXX'

access_token <- 'XXX'

access_secret <- 'XXX'
download.file(url="http://curl.haxx.se/ca/cacert.pem",destfile="cacert.pem")
setup_twitter_oauth(consumer_key,consumer_secret,access_token,access_secret)

tweet<-read.csv("twitter_data_techchallenge3.0.csv")
str(tweet)
length(tweet$userid)

tweetdata<-list()
uniqueuser<-unique(tweet$userid)
str(uniqueuser)
uniqueuser[1]

for(i in 1:length(uniqueuser))
{
  tryCatch({
  print(i)
 id<-as.character(uniqueuser[i])
 print(id)
  userdet<-getUser(id)
  followcnt<-userdet$followersCount
  friendcnt<-userdet$friendsCount
  df<-data.frame("Userid"=id,"Follower"=followcnt,"Friend"=friendcnt)
  tweetdata[[i]]<-df
}, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
}

tweetdf = do.call(rbind, tweetdata)
str(tweetdf)
tweetdf
#getUser("@albicule",includeNA=TRUE)
#a<-lookupUsers("@samir")
##rate.limit <- getCurRateLimitInfo()
#rate.limit$hourlyLimit
#rate.limit$remainingHits
#rate.limit$resetTime
warnings()

write.csv(tweetdf,"twitterstats.csv",row.names = F)
