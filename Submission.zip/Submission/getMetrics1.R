tweet<-read.csv("twitter_data_techchallenge3.0.csv",stringsAsFactors = F)
str(tweet)
library(sqldf)
nooftweets<-sqldf("select userid,count(*) as nooftweet,avg(authority) as avg_authority from tweet group by userid")
str(nooftweets)
write.csv(nooftweets,"tweetcnt.csv",row.names = F)
r<-regexpr("@([A-Za-z]+[A-Za-z0-9_]+)",tweet$contents)
out <- rep(NA,length(tweet$contents))
out[r!=-1] <- regmatches(tweet$contents, r)
toaccount<-out
str(toaccount)
tweet$toaccount<-(ifelse(is.na(toaccount),"NIL",toaccount))
str(tweet)
library(stringr)
tweet$noofreply<-str_count(tweet$contents,"@")
noofcontacts<-sqldf("select userid,sum(noofreply) as contactcnt
                    ,avg(noofreply) as contactavg from
                    tweet group by userid")
str(noofcontacts)
write.csv(noofcontacts,"contactcnt.csv",row.names = F)
library(plyr)
head(arrange(noofcontacts,desc(contactcnt)))
retweet<-sqldf("select distinct userid,toaccount,btoaccount from
                (select userid,toaccount from tweet)A
                inner join
               (select userid as buserid,toaccount as btoaccount from tweet)B
                on A.toaccount=B.buserid
               and b.btoaccount=a.userid")

str(retweet)
str(tweet)
