tweetdf<-read.csv("twitter_data_techchallenge3.0.csv",stringsAsFactors = F)
emotiondf<-read.csv("tweetemotion.csv",stringsAsFactors = F)
sentimentdata<-read.csv("sentiment.csv",stringsAsFactors = F)
twitterstats<-read.csv("twitterstats.csv",stringsAsFactors = F)
tweetcnt<-read.csv("tweetcnt.csv",stringsAsFactors = F)
contactcnt<-read.csv("contactcnt.csv",stringsAsFactors = F)
sentimentavg<-read.csv("sentimentuser.csv",stringsAsFactors = F)
str(twitterstats)

str(tweetcnt)
tweetcnt$Userid<-tweetcnt$userid
tweetcnt$userid<-NULL

contactcnt$Userid<-contactcnt$userid
contactcnt$userid<-NULL
finalds<-merge(twitterstats,tweetcnt,by="Userid")
str(finalds)
finalds<-merge(finalds,contactcnt,by="Userid")
str(finalds)
sentimentavg$Userid<-sentimentavg$userid
sentimentavg$userid<-NULL
str(sentimentavg)
finalds<-merge(finalds,sentimentavg,by="Userid")
str(finalds)
finalds$followerrank<-rank(finalds$Follower)/nrow(finalds)*100
finalds$friendrank<-rank(finalds$Friend)/nrow(finalds)*100
finalds$tweetrank<-rank(finalds$nooftweet)/nrow(finalds)*100
finalds$contactcntrank<-rank(-finalds$contactcnt)/nrow(finalds)*100
finalds$contactavgrank<-rank(-finalds$contactavg)/nrow(finalds)*100
finalds$avgauthority<-rank(finalds$avg_authority)/nrow(finalds)*100
str(finalds)
finalds$influence<-rank(-rowMeans(finalds[,c("followerrank","friendrank","tweetrank"
                                       ,"contactcntrank","contactavgrank","avgauthority")]))
rank(-finalds$influence)
finalds[finalds$influence<=25,]
finalds[which(finalds$Userid=="@beingsalmankhan"),]
