tweet<-read.csv("twitter_data_techchallenge3.0.csv",stringsAsFactors = F)

library(tm)
#library("Snowballc")


Corpus = Corpus(VectorSource(tweet$contents))

Corpus = tm_map(Corpus, tolower)

Corpus = tm_map(Corpus, PlainTextDocument)

Corpus = tm_map(Corpus, removePunctuation)

Corpus = tm_map(Corpus, removeWords, c("green","tea","greentea","drink",stopwords("english")))

Corpus = tm_map(Corpus, stemDocument,language="english")

dtm = DocumentTermMatrix(Corpus)

sparse = removeSparseTerms(dtm, 0.9)
sparse<-as.matrix(sparse)

dist<-dist(scale(sparse))
fit<-hclust(dist,method="ward")
library(wordcloud)
wordcloud(Corpus,max.words = 50)

library(syuzhet)
tweet$gs<-get_sentences(tweet$contents)
nrc<-get_nrc_sentiment(tweet$contents)
str(nrc)
nrc$userid<-tweet$userid
sumemotion<-as.data.frmcolSums(prop.table(nrc))
class(sumemotion)
str(sumemotion)
barplot(sort(colSums(prop.table(nrc[,1:10]))),main="Emotions",horiz = T,cex.names = 0.7,las = 1)
?barplot
str(sumemotion)

barplot(sumemotion,names.arg = c("anger","anticipation","disgust","fear","joy","sadness"
                           ,"surprise","trust","negative","positive"))

sumemotion<-tapply(nrc,anger,sum)
barplot(sumemotion,las=2)
barplot(sumemotion)
bar<-ggplot(sumemotion)
bar+stat_summary(fun.y=mean,geom="bar",fill="White",colour="Black")

write.csv(nrc,"tweetemotion.csv",row.names = F)

sentiment<-get_sentiment(tweet$contents, method="syuzhet")
str(sentiment)
class(sentiment)
sentimentdf<-data.frame(userid=tweet$userid,sentimentval=sentiment)
str(sentimentdf)
write.csv(sentimentdf,"sentiment.csv",row.names = F)
sentimentuser<-sqldf("select userid,avg(sentimentval) as avg_sentiment
                     from sentimentdf group by userid")
str(sentimentuser)
write.csv(sentimentuser,"sentimentuser.csv",row.names = F)
